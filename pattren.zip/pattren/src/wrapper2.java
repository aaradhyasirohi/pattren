public class wrapper2 {
    public static void main(String[] args) {
        Integer a=121;
        Integer b=121;
        Integer c=345;
        Integer d=345;
        System.out.println(a==b);
        System.out.println(c==d);
    }
}
