public class function4  {
    public static void main(String[] args) {

        System.out.println(v);
        fun();
        System.out.println(v);
    }
     static int v =10;
    public static void fun() {
        int v =90;
        System.out.println(v+90);
        System.out.println(v);
        v=v+4;
        System.out.println(v);

    }
}
