public class Function3 {

        public static void main(String[] args) {
            System.out.println("hey");
            int a= 9;
            int b=78;
           // int ans = addition(a,b);
           // System.out.println(ans);
            System.out.println(addition(a,b));

        }
        public static int addition(int a ,int b) {

            // sub(a,b);
            int m = a + b;
           
            return m;
        }
}
