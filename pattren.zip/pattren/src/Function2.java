public class Function2 {
    public static void main(String[] args) {
         int a= 9;
         int b=78;
            addition(a,b);

        }
        public static void addition(int a ,int b){

            sub(a,b);
            int m =a+b;
            System.out.println(m);
    }
    public static void sub(int c ,int d){

        // sub();
        int m =c-d;
        System.out.println(m);
    }
}
