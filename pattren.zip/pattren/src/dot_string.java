import java.util.Scanner;

public class dot_string {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

    }
}
