public class function {
    public static void main(String[] args) {
        addition();

    }
    public static void addition(){
        int a =9;
        int b=11;
        sub();
        int c =a+b;
        System.out.println(c);
    }
    public static void sub(){
        int a =8;
        int b=11;
        int c =a-b;
        System.out.println(c);
    }
}
