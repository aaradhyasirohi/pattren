public class client {
    public static void main(String[] args) {
      // P obj=new P();
       P obj1=new C();
        System.out.println(obj1.d);
        System.out.println(obj1.d1);
        System.out.println(((C)(obj1)).d2);
        System.out.println(((C)(obj1)).d);
        // override
        obj1.fun();
        ((C)(obj1)).fun2();
    }
}
