public class P {
    int d=1;
    int d1=2;
    public void fun(){
        System.out.println("Fun is p");
    }
    public void fun1(){
        System.out.println("Fun1 in p");
    }
}
