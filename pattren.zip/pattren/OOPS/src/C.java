public class C extends P{
    int d=2;
    int d2 =20;
    @Override
    public void fun(){
        System.out.println("Fun is c");
    }
    public void fun2(){
        System.out.println("Fun1 in c");
    }
               

}
