import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

public class prac {
    public static void main(String[] args) {
      
        String str = "fuckedup" ;
        String str2 = "" ;
//        boolean a=true;
//        for (int i = 0; i <str.length(); i++) {
//                   char b=str.charAt(i);
//            for (int j = i+1; j <str.length(); j++) {
//                if(str.charAt(i)==str.charAt(j)){
//                     a=false;
//                     break;
//                }
//            }
//            if(a==true) str2=str2+b;
//            a=true;
//        }
//        System.out.println(str2);
        HashSet<Character> set=new HashSet<>();
        for (int i = 0; i < str.length(); i++) {
               set.add(str.charAt(i));
        }
      Iterator<Character> it=set.iterator();
       while (it.hasNext()){
           System.out.print(it.next());
       }

    }
       
    }