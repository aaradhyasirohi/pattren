import java.util.ArrayList;

public class op1 {
    public static void main(String[] args) {
        System.out.println('a');
        System.out.println('a'+'b');
        System.out.println('a'+3);
        System.out.println((char)('a'+3));
        System.out.println("khushi"+ new ArrayList<>());
    }
}
